<?php
session_start();
require_once 'config/database.php';
require_once 'vendor/autoload.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$conn = getDBConnection();

// Ambil data user
$query = "SELECT * FROM users WHERE id = :user_id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Ambil semua sesi tes yang sudah selesai
$query = "SELECT ts.*, t.nama_tes, t.durasi_menit, s.nama_subject, s.id as subject_id
          FROM test_sessions ts 
          JOIN tests t ON ts.test_id = t.id 
          JOIN subjects s ON t.subject_id = s.id 
          WHERE ts.user_id = :user_id AND ts.status = 'completed'
          ORDER BY ts.waktu_selesai DESC";
$stmt = $conn->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Hitung statistik per mata pelajaran
$subject_stats = [];
foreach ($sessions as $session) {
    $subject_id = $session['subject_id'];
    $subject_name = $session['nama_subject'];
    
    if (!isset($subject_stats[$subject_id])) {
        $subject_stats[$subject_id] = [
            'nama' => $subject_name,
            'total_tes' => 0,
            'total_skor' => 0,
            'skor_tertinggi' => 0,
            'skor_terendah' => 100,
            'tes_terakhir' => null
        ];
    }
    
    $subject_stats[$subject_id]['total_tes']++;
    $subject_stats[$subject_id]['total_skor'] += $session['total_skor'];
    
    if ($session['total_skor'] > $subject_stats[$subject_id]['skor_tertinggi']) {
        $subject_stats[$subject_id]['skor_tertinggi'] = $session['total_skor'];
    }
    
    if ($session['total_skor'] < $subject_stats[$subject_id]['skor_terendah']) {
        $subject_stats[$subject_id]['skor_terendah'] = $session['total_skor'];
    }
    
    if (!$subject_stats[$subject_id]['tes_terakhir'] || 
        strtotime($session['waktu_selesai']) > strtotime($subject_stats[$subject_id]['tes_terakhir']['waktu_selesai'])) {
        $subject_stats[$subject_id]['tes_terakhir'] = $session;
    }
}

// Hitung rata-rata per mata pelajaran
foreach ($subject_stats as &$stat) {
    $stat['rata_rata'] = $stat['total_tes'] > 0 ? round($stat['total_skor'] / $stat['total_tes'], 2) : 0;
    if ($stat['skor_terendah'] == 100 && $stat['total_tes'] > 0) {
        $stat['skor_terendah'] = $stat['skor_tertinggi'];
    }
}

// Fungsi untuk menentukan level kompetensi
function getCompetencyLevel($score) {
    if ($score >= 85) return ['level' => 'Mahir', 'color' => '#38a169', 'description' => 'Sangat baik dalam menguasai kompetensi'];
    if ($score >= 70) return ['level' => 'Cakap', 'color' => '#3182ce', 'description' => 'Baik dalam menguasai kompetensi'];
    if ($score >= 55) return ['level' => 'Layak', 'color' => '#ed8936', 'description' => 'Cukup dalam menguasai kompetensi'];
    return ['level' => 'Perlu Intervensi', 'color' => '#e53e3e', 'description' => 'Memerlukan bimbingan tambahan'];
}

// Hitung statistik keseluruhan
$total_tes = count($sessions);
$total_skor_keseluruhan = array_sum(array_column($sessions, 'total_skor'));
$rata_rata_keseluruhan = $total_tes > 0 ? round($total_skor_keseluruhan / $total_tes, 2) : 0;
$skor_tertinggi_keseluruhan = $total_tes > 0 ? max(array_column($sessions, 'total_skor')) : 0;
$skor_terendah_keseluruhan = $total_tes > 0 ? min(array_column($sessions, 'total_skor')) : 0;

// Buat PDF menggunakan TCPDF
class MYPDF extends TCPDF {
    public function Header() {
        // Logo atau header
        $this->SetFont('helvetica', 'B', 16);
        $this->Cell(0, 15, 'Contoh Laporan Hasil Analisis AKM', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        $this->Ln(20);
    }
    
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'PINRANG,', 0, false, 'R', 0, '', 0, false, 'T', 'M');
    }
}

// Buat instance PDF
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set informasi dokumen
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('CLASNET ACADEMY');
$pdf->SetTitle('Laporan Hasil Analisis AKM');
$pdf->SetSubject('Analisis Hasil Asesmen Kompetensi Minimum');
$pdf->SetKeywords('AKM, Laporan, Kompetensi, Siswa');

// Set margin
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 10);

// Informasi Sekolah dan Siswa
$html = '
<table border="0" cellpadding="3" cellspacing="0" width="100%">
    <tr>
        <td width="20%"><strong>Sekolah</strong></td>
        <td width="5%">:</td>
        <td width="75%"></td>
    </tr>
    <tr>
        <td><strong>Judul</strong></td>
        <td>:</td>
        <td>Analisis Hasil Asesmen Kompetensi Minimum (AKM) Siswa Kelas [Kelas], [Sekolah], Tahun Ajaran [Tahun]</td>
    </tr>
    <tr>
        <td><strong>Ringkasan</strong></td>
        <td>:</td>
        <td></td>
    </tr>
</table>
<br>
Analisis AKM menunjukkan [jelaskan temuan utama secara singkat, misal: kekuatan siswa dalam literasi numerik, namun masih perlu peningkatan dalam literasi membaca].
<br><br>

<strong>Temuan Utama</strong>
<br><br>

<table border="1" cellpadding="5" cellspacing="0" width="100%">
    <tr style="background-color: #f0f0f0;">
        <th width="25%"><strong>Kompetensi</strong></th>
        <th width="25%"><strong>Kekuatan</strong></th>
        <th width="25%"><strong>Kelemahan</strong></th>
    </tr>
    <tr>
        <td>Literasi Membaca</td>
        <td>[Contoh: Memahami teks naratif]</td>
        <td>[Contoh: Menganalisis teks nonfiksi]</td>
    </tr>
    <tr>
        <td>Numerasi</td>
        <td>[Contoh: Perhitungan dasar]</td>
        <td>[Contoh: Pemecahan masalah]</td>
    </tr>
    <tr>
        <td>Ekspor ke Spreadsheet</td>
        <td></td>
        <td></td>
    </tr>
</table>
<br>

<strong>Rekomendasi</strong>
<br><br>
• <strong>Literasi Membaca:</strong> [Contoh: Perbanyak kegiatan membaca, gunakan berbagai jenis teks, latih keterampilan berpikir kritis]<br>
• <strong>Numerasi:</strong> [Contoh: Perkuat pemahaman konsep matematika, gunakan media pembelajaran yang menarik, berikan soal-soal yang bervariasi]<br><br>

<strong>Kesimpulan:</strong>
<br><br>
Berdasarkan hasil analisis, perlu dilakukan perbaikan pada [jelaskan area yang perlu diperbaiki] untuk meningkatkan kualitas pembelajaran.
<br><br><br>

<table border="0" cellpadding="3" cellspacing="0" width="100%">
    <tr>
        <td width="50%"></td>
        <td width="50%" align="center">
            PINRANG,<br><br><br>
            MENGETAHUI<br>
            KEPALA SEKOLAH<br><br><br><br><br>
            KETUA GOMBEL
        </td>
    </tr>
</table>
';

// Tulis HTML ke PDF
$pdf->writeHTML($html, true, false, true, false, '');

// Output PDF
$filename = 'Laporan_AKM_' . $user['username'] . '_' . date('Y-m-d') . '.pdf';
$pdf->Output($filename, 'D'); // 'D' untuk download
?>